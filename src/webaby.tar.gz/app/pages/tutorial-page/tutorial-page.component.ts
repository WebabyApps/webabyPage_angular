import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { HeroComponent } from '../../shared/hero/hero.component';
import { TutorialSectionComponent } from '../../shared/tutorial-section/tutorial-section.component';
import { FadeInOnScrollDirective } from '../../shared/directives/fade-in-on-scroll.directive';
import { TranslocoModule, TranslocoService } from '@jsverse/transloco';
import { take } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { map, switchMap, filter } from 'rxjs/operators';
import { combineLatest, of } from 'rxjs';


@Component({
  selector: 'app-tutorial-page',
  standalone: true,
  imports: [
    CommonModule,
    HeroComponent,
    TutorialSectionComponent,
    FadeInOnScrollDirective,
    TranslocoModule
  ],
  templateUrl: './tutorial-page.component.html',
  styleUrls: ['./tutorial-page.component.scss']
})
export class TutorialPageComponent implements OnInit {
  startMenuItems$ = new BehaviorSubject<any[]>([]);
  soundItems$     = new BehaviorSubject<any[]>([]);

  slug = '';
  productTitle = '';
  scopePath: string | null = null;
  heroTitle$    = of<string>('');
heroSubtitle$ = of<string>('');
heroCta$      = of<string>('');

  constructor(
    private route: ActivatedRoute,
    private transloco: TranslocoService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(pm => {
      const fromParam = pm.get('slug') ?? '';
      const fromData  = (this.route.snapshot.data['slug'] as string) ?? '';
      this.slug = fromParam || fromData;

      this.productTitle = this.prettyTitle(this.slug);
     // this.scopePath    = this.slug ? this.slug : null; // ✅ slug-only, loader normalizes
     this.scopePath = this.slug ? `tutorials/${this.slug}` : null;
     if (this.scopePath) {
      // ✅ resolve via service (this code path already works in your app)
      this.heroTitle$ = this.transloco.selectTranslate('hero.title', {}, this.scopePath);
      this.heroSubtitle$ = this.transloco.selectTranslate('hero.subtitle', {}, this.scopePath);
      this.heroCta$ = this.transloco.selectTranslate('hero.back', {}, this.scopePath);
    
      // keep your arrays loader
      this.loadSectionArrays();
    
      // optional: quick console sanity
      this.transloco.selectTranslate('hero.title', {}, this.scopePath).pipe(take(1))
        .subscribe(v => console.log('[i18n] hero.title@', this.scopePath, '->', v));
    }
      this.loadSectionArrays();
      this.debugScope();
    });
  }

  /** Debug log for hero subtitle */
  private debugScope() {
    if (this.scopePath) {
      this.transloco
        .selectTranslate('hero.subtitle', {}, this.scopePath)
        .pipe(take(1))
        .subscribe(val =>
          console.log('[i18n] hero.subtitle@' + this.scopePath, val)
        );
    }
  }

  /** Load translatable arrays for *ngFor usage */
  private loadSectionArrays() {
    if (!this.scopePath) {
      this.startMenuItems$.next([]);
      this.soundItems$.next([]);
      return;
    }

    // ✅ Directly select arrays from scope
    this.transloco
      .selectTranslate('sections.startMenu.items', {}, this.scopePath)
      .pipe(take(1))
      .subscribe((items: any) => {
        console.debug('[i18n] startMenu.items', items);
        this.startMenuItems$.next(Array.isArray(items) ? items : []);
      });

    this.transloco
      .selectTranslate('sections.sound.items', {}, this.scopePath)
      .pipe(take(1))
      .subscribe((items: any) => {
        console.debug('[i18n] sound.items', items);
        this.soundItems$.next(Array.isArray(items) ? items : []);
      });
  }

  /** Utility for pretty product title */
  private prettyTitle(slug: string): string {
    const names: Record<string, string> = {
      abecadlowo: 'Abecadłowo',
      'basketball-shots': 'Basketball-shots',
      'system-of-equations-trainer': 'System-of-equations-trainer',
      'abc-land': 'ABC Land'
    };
    return names[slug] ?? this.capitalize(slug);
  }

  private capitalize(s: string) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
  }
}
