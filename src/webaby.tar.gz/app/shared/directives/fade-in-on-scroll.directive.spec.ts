import { FadeInOnScrollDirective } from './fade-in-on-scroll.directive';

describe('FadeInOnScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new FadeInOnScrollDirective();
    expect(directive).toBeTruthy();
  });
});
