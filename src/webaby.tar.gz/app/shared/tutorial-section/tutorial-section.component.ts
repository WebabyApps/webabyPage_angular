import { Component, Input } from '@angular/core';
import { NgIf, NgClass } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { FadeInOnScrollDirective } from '../directives/fade-in-on-scroll.directive';
import { TranslocoModule } from '@jsverse/transloco'; 

@Component({
  selector: 'app-tutorial-section',
  standalone: true,
  imports: [NgIf, NgClass, FadeInOnScrollDirective, TranslocoModule],
  templateUrl: './tutorial-section.component.html',
  styleUrls: ['./tutorial-section.component.scss'],
})
export class TutorialSectionComponent {
  // Text (already translated in parent)
  @Input() title?: string;
  @Input() caption?: string;
  @Input() alt?: string;

  // Layout
  @Input() reverse = false;

  // Image
  @Input() img = '';
  @Input() lazyImg = true;

  // YouTube
  @Input() youtubeId = '';
  @Input() youtubeUrl = '';
  @Input() start = 0;            // seconds
  @Input() autoplay = false;
  @Input() modestBranding = true;
  @Input() rel = 0;              // 0 = no related
  @Input() lazyVideo = false;

  constructor(private sanitizer: DomSanitizer) {}

  get videoId(): string | null {
    if (this.youtubeId) return this.youtubeId.trim();
    if (!this.youtubeUrl) return null;
    const m =
      this.youtubeUrl.match(/[?&]v=([^&#]+)/) ||
      this.youtubeUrl.match(/youtu\.be\/([^?&#/]+)/) ||
      this.youtubeUrl.match(/youtube\.com\/embed\/([^?&#/]+)/);
    return m ? m[1] : null;
  }

  get embedUrl(): SafeResourceUrl | null {
    const id = this.videoId;
    if (!id) return null;
    const params = new URLSearchParams({
      autoplay: this.autoplay ? '1' : '0',
      start: String(this.start || 0),
      modestbranding: this.modestBranding ? '1' : '0',
      rel: String(this.rel ?? 0),
      playsinline: '1'
    }).toString();
    return this.sanitizer.bypassSecurityTrustResourceUrl(
      `https://www.youtube-nocookie.com/embed/${id}?${params}`
    );
  }

  get showVideo(): boolean {
    return !!this.embedUrl;
  }
}
