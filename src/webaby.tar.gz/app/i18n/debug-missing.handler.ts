import { Injectable } from '@angular/core';
import {
  TranslocoMissingHandler,
  TranslocoMissingHandlerData,
  HashMap,
} from '@jsverse/transloco';

@Injectable({ providedIn: 'root' })
export class DebugMissingHandler implements TranslocoMissingHandler {
    handle(key: string, data: TranslocoMissingHandlerData, params?: HashMap): any {
        const scope =
          data.scopes && typeof data.scopes === 'object'
            ? Object.keys(data.scopes)[0]
            : null;
      
        const lang = data.activeLang ?? 'en';
        const fileUrl = scope ? `assets/i18n/${scope}/${lang}.json` : `assets/i18n/${lang}.json`;
      
        console.warn('[i18n missing]', { key, scope, lang, fileUrl, params, data });
        console.trace('[i18n missing] call stack');   // 👈 shows which template/file fired it
        return `[MISSING: ${scope ? scope + '.' : ''}${key}]`;
      }
      
}
