// src/app/i18n/transloco-root.module.ts
import { Injectable, NgModule } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  TranslocoModule, TranslocoLoader, Translation,
  translocoConfig, provideTransloco, TRANSLOCO_MISSING_HANDLER,
} from '@jsverse/transloco';
import { DebugMissingHandler } from './debug-missing.handler';


@Injectable({ providedIn: 'root' })
export class TranslocoHttpLoader implements TranslocoLoader {
  constructor(private http: HttpClient) {}

  getTranslation(lang: string, data?: any) {
    let actualLang = lang;
    let scopePath: string | null = null;

    // Case: 'tutorials/abc-land/en'
    const m = /^(.*)\/(en|pl)$/.exec(lang);
    if (m) {
      scopePath = m[1];
      actualLang = m[2];
    }

    // Case: scope provided via data
    if (!scopePath && data && typeof data === 'object' && typeof data.scope === 'string') {
      scopePath = data.scope;
    }

    // --- normalize scope (maps slug-only → folder path, prevents double "tutorials/") ---
    const normalizeScope = (s?: string | null) => {
      if (!s) return null;

      if (s.startsWith('tutorials/')) return s;

      const alias: Record<string, string> = {
        'abc-land': 'tutorials/abc-land',
        'abecadlowo': 'tutorials/abecadlowo',
        'basketball-shots': 'tutorials/basketball-shots',
        'system-of-equations-trainer': 'tutorials/system-of-equations-trainer'
      };
      return alias[s] ?? s;
    };

    // ✅ normalize what we already have
    scopePath = normalizeScope(scopePath);

    // ✅ extra safety: sometimes Transloco passes scope via "lang" directly
    if (!scopePath && ['abc-land', 'abecadlowo', 'basketball-shots', 'system-of-equations-trainer'].includes(lang)) {
      scopePath = normalizeScope(lang);
      actualLang = 'en'; // or your defaultLang
    }

    // Build URL
    const url = scopePath
      ? `assets/i18n/${scopePath}/${actualLang}.json`
      : `assets/i18n/${actualLang}.json`;


    console.log('[i18n loader] request', { url, scopePath, actualLang, fromLangArg: lang, data });
    return this.http.get<Translation>(url);
  }
}


@NgModule({
  imports: [TranslocoModule],
  exports: [TranslocoModule],
  providers: [
    provideTransloco({
      config: translocoConfig({
        availableLangs: ['en','pl'],
        defaultLang: 'en',
        fallbackLang: 'en',
        reRenderOnLangChange: true,
        prodMode: false,
        missingHandler: {
          logMissingKey: true,
          useFallbackTranslation: false,
          allowEmpty: false,
        },
      }),
      loader: TranslocoHttpLoader,
    }),
      // ⬇️ This is where your custom handler is actually plugged in
      { provide: TRANSLOCO_MISSING_HANDLER, useClass: DebugMissingHandler },
  ],
})
export class TranslocoRootModule {}
